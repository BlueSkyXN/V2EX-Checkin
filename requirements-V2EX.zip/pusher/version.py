# Don't change the format of this line: the version is extracted by ../setup.py
VERSION = '3.0.0'
